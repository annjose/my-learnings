//
//  ViewController.h
//  EmbededReactNative
//
//  Created by Wu Di on 3/31/15.
//  Copyright (c) 2015 吴迪（子回）. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

