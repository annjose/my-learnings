# EmbededReactNativeExample

See [tutorial](http://blog-en.leapoahead.com/post/use-react-native-in-existing-ios-app).